<?php include '_header.php'; ?>
<!-- content -->
<div class="container mt-5">
    <?php include 'page_home.php'; ?>
</div>
<!-- ./content -->
<?php include '_footer.php'; ?>