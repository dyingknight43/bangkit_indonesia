<div class="card im-box">
    <h5 class="card-header">Selamat Datang</h5>
    <div class="card-body">
        <h5 class="card-title">Simple CRUD PHP Native dengan Tema Bela Negara</h5>
        <p class="card-text">Kita tidak boleh berhenti berkreasi, berinovasi, dan berprestasi. Kita harus buktikan ketangguhan kita. Kita harus menangkan masa depan kita dan kita wujudkan cita-cita para Pendiri Bangsa dengan semangat bela negara</p>
        <p class="card-text"> </p>KELOMPOK 4 :
</p> Class(77.9E3.07)
</p>Hilya Sabila Bey (77222292)
</p>Aldenusa Ramadhan (77222277)
</p>Tiara Salsabillah Putri (77222291)
</p>Osa Lazuardi (77222305)
</p>Muhammad Danyal Nur Farouq (77222289)
</p>Denysyah Uqbah (77222282)
</p>Irfansyah Supandiwinata (77222281)
</p>Chika Dyah Kinanti (77222301)
</p>Sadam Azizan (77222287)
</p>Alghifari Shabri Naufal (77222293) ,</p>

        <a href="page_about.php" class="btn btn-primary">Learn More</a>
    </div>
</div>